# Android 工程安全筛查

检查范围：`android-app` 当前 Flutter 源码、离线 JSON 资料、图片资源和 GitHub Actions 工作流。

## 已检查项目

- 产品目录、案例图片和施工资料均从应用内资源读取；不读取外部文件，也不执行动态代码。
- 未声明通讯录、定位、相机、存储等 Android 敏感权限；资料从应用内资源读取。
- JSON 只作为本地展示数据解析，不作为代码或路径执行。
- 搜索和详情页均只在内存中的内置资料上操作。
- 在线咨询仅在用户主动配置 OpenAI 兼容 API 后发起 HTTPS 请求；Key 使用系统安全存储保存在该手机本机，未写入源码、资料包或工作流。
- 工作流不读取 secrets，也不上传源码；只上传构建生成的 APK artifact。
- 依赖包括 Flutter SDK、`http`、`flutter_secure_storage`、`cupertino_icons` 和开发期 lint/test 工具。
- 离线资料读取失败有明确重试入口，图片失败不会破坏页面布局。
- GitHub 云端在干净环境执行格式检查、静态分析和全部组件测试，通过后才生成 APK。
- 当前定位为培训与销售辅助工具，不包含企业账号、统一权限、审计或集中数据后台。

## 低风险注意项

GitHub Actions 当前使用版本标签（如 `actions/checkout@v4`）。这属于供应链可追溯性改进项，不是当前应用漏洞；正式发布前可将 Actions 固定到具体 commit SHA。

## 结论

云端发布必须依次通过 `dart format`、`flutter analyze`、`flutter test` 和 release APK 构建。最终 APK 仍需检查 Manifest 权限列表与文件哈希。
