import 'package:flutter/material.dart';
import '../catalog/catalog_item.dart';
import '../library/portfolio_page.dart';
import '../theme/app_theme.dart';
import '../widgets/app_image.dart';
import '../widgets/section_header.dart';

class HomePage extends StatelessWidget {
  const HomePage(
      {super.key,
      required this.items,
      required this.onCatalog,
      required this.onAdvisor,
      required this.onSeries});
  final List<CatalogItem> items;
  final VoidCallback onCatalog;
  final VoidCallback onAdvisor;
  final ValueChanged<String> onSeries;

  @override
  Widget build(BuildContext context) {
    final count = items.where((item) => item.isProduct).length;
    final series = items
        .where((item) => item.isProduct)
        .map((item) => item.series)
        .toSet()
        .take(7)
        .toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        _hero(count),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
              child: FilledButton.icon(
                  onPressed: onAdvisor,
                  icon: const Icon(Icons.auto_awesome_outlined),
                  label: const Text('智能选型'))),
          const SizedBox(width: 10),
          Expanded(
              child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 48),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8))),
                  onPressed: onCatalog,
                  icon: const Icon(Icons.menu_book_outlined),
                  label: const Text('浏览产品')))
        ]),
        const SizedBox(height: 22),
        const SectionHeader('产品系列'),
        const SizedBox(height: 8),
        SizedBox(
          height: 94,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: series.length,
            separatorBuilder: (_, __) => const SizedBox(width: 9),
            itemBuilder: (_, index) => _seriesCard(series[index]),
          ),
        ),
        const SizedBox(height: 22),
        SectionHeader('真实产品与工程案例',
            action: '查看全部',
            onAction: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PortfolioPage()))),
        const SizedBox(height: 8),
        SizedBox(
          height: 150,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: 5,
            separatorBuilder: (_, __) => const SizedBox(width: 9),
            itemBuilder: (_, index) => _caseCard(portfolioCases[index]),
          ),
        ),
      ],
    );
  }

  Widget _hero(int count) => Stack(
        alignment: Alignment.bottomLeft,
        children: [
          const AppImage('assets/portfolio/product-range.jpg',
              height: 220, width: double.infinity),
          Container(
              height: 220,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Color(0xd918232d)]))),
          Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('永兴涂料',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 7),
                    Text('$count 类正式产品 · 工程案例 · 销售选型',
                        style:
                            const TextStyle(color: Colors.white, fontSize: 14))
                  ])),
        ],
      );

  Widget _seriesCard(String name) => SizedBox(
        width: 126,
        child: Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => onSeries(name),
            child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Icon(Icons.format_paint_outlined, color: brandTeal),
                      Text(name,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, height: 1.3))
                    ])),
          ),
        ),
      );

  Widget _caseCard(List<String> item) => SizedBox(
        width: 210,
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            AppImage(item[1], width: 210, height: 150),
            Container(
                width: 210,
                height: 150,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xb818232d)]))),
            Padding(
                padding: const EdgeInsets.all(12),
                child: Text(item[0],
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w800))),
          ],
        ),
      );
}
