import 'package:flutter/material.dart';
import '../advisor/consultation_page.dart';
import '../advisor/offline_selection_page.dart';
import '../catalog/catalog_item.dart';
import '../theme/app_theme.dart';
import 'color_card_page.dart';
import 'library_content.dart';
import 'portfolio_page.dart';
import 'reference_detail_page.dart';
import 'sales_library_page.dart';
import 'sales_templates_page.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key, required this.items});
  final List<CatalogItem> items;
  @override
  Widget build(BuildContext context) {
    final references = items.where((x) => !x.isProduct).toList();
    return ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          const Text('销售与资料中心',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 7),
          const Text('电脑版 0.1.8 的选型、沟通、颜色、证书与施工资料已集中到这里。',
              style: TextStyle(height: 1.55, color: appMuted)),
          const SizedBox(height: 16),
          ...libraryEntries.map((entry) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Card(
                  child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 13, vertical: 7),
                      leading: Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                              color: const Color(0xffe7f1f0),
                              borderRadius: BorderRadius.circular(7)),
                          child: Icon(entry.icon, color: brandTeal)),
                      title: Text(entry.title,
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text(entry.description,
                          maxLines: 2, overflow: TextOverflow.ellipsis),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => _open(context, entry.title, references))))),
        ]);
  }

  void _open(BuildContext context, String title, List<CatalogItem> references) {
    final Widget page;
    switch (title) {
      case '海外销售选型库':
        page = const SalesLibraryPage();
      case '英文沟通模板':
        page = const SalesTemplatesPage();
      case '在线场景咨询':
        page = ConsultationPage(items: items);
      case '离线场景库':
        page = const OfflineSelectionPage();
      case '比色卡':
        page = const ColorCardPage();
      case '工程案例':
        page = const PortfolioPage();
      default:
        page = ReferenceDetailPage(title: title, references: references);
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }
}
