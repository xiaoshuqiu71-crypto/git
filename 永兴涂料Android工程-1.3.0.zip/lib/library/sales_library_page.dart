import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'library_content.dart';

class SalesLibraryPage extends StatelessWidget {
  const SalesLibraryPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('海外销售选型库')),
      body: ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
          itemCount: salesSystems.length + 1,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, index) {
            if (index == 0) {
              return const Padding(
                  padding: EdgeInsets.only(bottom: 4),
                  child: Text('先看真实工况，再选择够用且不过度配置的体系。强腐蚀、浸泡、高温和食品相关用途必须技术确认。',
                      style: TextStyle(height: 1.6, color: appMuted)));
            }
            final item = salesSystems[index - 1];
            return Card(
                child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item['title']!,
                              style: const TextStyle(
                                  fontSize: 17, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 7),
                          Text(item['use']!,
                              style: const TextStyle(height: 1.55)),
                          const SizedBox(height: 7),
                          Text(item['system']!,
                              style: const TextStyle(
                                  height: 1.55,
                                  color: brandTeal,
                                  fontWeight: FontWeight.w700)),
                          const SizedBox(height: 7),
                          Text(item['note']!,
                              style:
                                  const TextStyle(height: 1.5, color: appMuted))
                        ])));
          }));
}
