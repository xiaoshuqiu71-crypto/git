import 'package:flutter/material.dart';
import '../catalog/catalog_item.dart';
import '../catalog/product_detail_page.dart';

class ReferenceDetailPage extends StatelessWidget {
  const ReferenceDetailPage(
      {super.key, required this.title, required this.references});
  final String title;
  final List<CatalogItem> references;
  @override
  Widget build(BuildContext context) {
    final keys = title == 'RoHS 证书'
        ? ['RoHS']
        : title == '技术说明书'
            ? ['技术说明']
            : title == '施工工艺'
                ? ['施工工艺']
                : ['施工方案'];
    final matches =
        references.where((item) => keys.any(item.name.contains)).toList();
    return Scaffold(
        appBar: AppBar(title: Text(title)),
        body: matches.isEmpty
            ? const Center(child: Text('暂未找到对应资料'))
            : ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: matches.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final item = matches[index];
                  return Card(
                      child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 8),
                          title: Text(item.name,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(item.usage),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) =>
                                      ProductDetailPage(item: item)))));
                }));
  }
}
