import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import 'library_content.dart';

class SalesTemplatesPage extends StatelessWidget {
  const SalesTemplatesPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('英文沟通模板')),
      body: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: englishTemplates.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final item = englishTemplates[index];
            return Card(
                child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Expanded(
                                child: Text(item['title']!,
                                    style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w800))),
                            IconButton(
                                tooltip: '复制英文',
                                onPressed: () {
                                  Clipboard.setData(
                                      ClipboardData(text: item['text']!));
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('英文模板已复制')));
                                },
                                icon: const Icon(Icons.copy_outlined))
                          ]),
                          SelectableText(item['text']!,
                              style:
                                  const TextStyle(height: 1.65, color: appInk))
                        ])));
          }));
}
