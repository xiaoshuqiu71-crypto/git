import 'package:flutter/material.dart';
import '../widgets/app_image.dart';

const portfolioCases = <List<String>>[
  ['产品系列', 'assets/portfolio/product-range.jpg', '工业涂料正式产品系列'],
  ['成品包装', 'assets/portfolio/product-can.jpg', '豫虹工业涂料包装展示'],
  ['整托交付', 'assets/portfolio/shipment-red.jpg', '成品包装与发货准备'],
  ['出口包装', 'assets/portfolio/shipment-blue.jpg', '整托缠膜与装运准备'],
  ['桥梁钢构防腐', 'assets/portfolio/steel-bridge.jpg', '大型钢构涂装案例'],
  ['钢构涂层实拍', 'assets/portfolio/steel-coating.jpg', '重防腐涂层施工效果'],
  ['环氧地坪', 'assets/portfolio/floor-green.jpg', '车间地坪与安全分区'],
  ['环氧地坪', 'assets/portfolio/floor-gray.jpg', '仓储空间地坪施工过程'],
  ['彩砂装饰地坪', 'assets/portfolio/floor-terrazzo.jpg', '耐磨装饰地坪表面效果'],
];

class PortfolioPage extends StatelessWidget {
  const PortfolioPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('产品与工程案例')),
      body: GridView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: portfolioCases.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: .79),
          itemBuilder: (context, index) {
            final item = portfolioCases[index];
            return Card(
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                    onTap: () => showDialog(
                        context: context,
                        builder: (_) => Dialog(
                            insetPadding: const EdgeInsets.all(16),
                            child: InteractiveViewer(
                                child: AppImage(item[1],
                                    fit: BoxFit.contain, borderRadius: 0)))),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                              child: AppImage(item[1],
                                  width: double.infinity, borderRadius: 0)),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(10, 9, 10, 2),
                              child: Text(item[0],
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700))),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 9),
                              child: Text(item[2],
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 12, height: 1.35)))
                        ])));
          }));
}
