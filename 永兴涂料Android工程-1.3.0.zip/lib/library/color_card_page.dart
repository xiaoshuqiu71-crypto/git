import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class ColorCardPage extends StatelessWidget {
  const ColorCardPage({super.key});
  static const colors = <List<Object>>[
    ['大红', 0xffc62828],
    ['橘红', 0xffef6c00],
    ['中黄', 0xffffc107],
    ['草绿', 0xff43a047],
    ['翠绿', 0xff008c6a],
    ['天蓝', 0xff42a5f5],
    ['海蓝', 0xff1565c0],
    ['紫色', 0xff7b1fa2],
    ['白色', 0xfff5f5f5],
    ['浅灰', 0xffb0bec5],
    ['中灰', 0xff78909c],
    ['黑色', 0xff202124],
    ['银灰', 0xff9e9e9e],
    ['铁红', 0xff8d3b32],
    ['棕色', 0xff6d4c41],
    ['米黄', 0xffe4cf91],
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('比色卡')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('常用颜色参考',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text(
            '普通油漆可按项目需要调色；环氧彩砂自流平漆不适用本色卡。屏幕显示存在色差，最终颜色必须以双方确认的实物样板或标准色号为准。',
            style: TextStyle(height: 1.65, color: appMuted)),
        const SizedBox(height: 18),
        GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: colors.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 2.15),
            itemBuilder: (_, index) {
              final value = colors[index];
              final color = Color(value[1] as int);
              return Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: appLine),
                      borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.all(8),
                  child: Row(children: [
                    Container(
                        width: 52,
                        height: double.infinity,
                        decoration: BoxDecoration(
                            color: color,
                            border: Border.all(color: appLine),
                            borderRadius: BorderRadius.circular(5))),
                    const SizedBox(width: 10),
                    Expanded(
                        child: Text(value[0] as String,
                            style:
                                const TextStyle(fontWeight: FontWeight.w700)))
                  ]));
            }),
        const SizedBox(height: 16),
        const Text('透明清漆通常呈无色透明至微黄色，具体颜色受树脂、膜厚与老化影响；底漆颜色由品种和防锈颜料决定，并非统一颜色。',
            style: TextStyle(height: 1.65, color: appMuted))
      ]));
}
