import 'package:flutter/material.dart';

class LibraryEntry {
  const LibraryEntry(this.title, this.description, this.icon);
  final String title;
  final String description;
  final IconData icon;
}

const libraryEntries = <LibraryEntry>[
  LibraryEntry('海外销售选型库', '按工况理解经济型、重防腐、耐候与环保体系', Icons.public),
  LibraryEntry('英文沟通模板', '询盘澄清、经济方案、寿命升级与技术确认', Icons.translate),
  LibraryEntry('在线场景咨询', '输入任意客户描述，先列出全部可能涂装部位', Icons.auto_awesome_outlined),
  LibraryEntry('离线场景库', '无网络时按已知工况快速查看候选体系', Icons.psychology_outlined),
  LibraryEntry('比色卡', '普通涂料颜色参考，最终以实物样板为准', Icons.palette_outlined),
  LibraryEntry('技术说明书', '环氧彩砂自流平产品技术参考', Icons.description_outlined),
  LibraryEntry('施工工艺', '彩砂自流平基层、底涂、砂浆、面层与养护', Icons.construction_outlined),
  LibraryEntry('施工方案', '环氧地坪基面检查、修补与底中面施工', Icons.assignment_outlined),
  LibraryEntry('RoHS 证书', '欧盟符合性资料与适用范围核对提示', Icons.verified_outlined),
  LibraryEntry('工程案例', '产品、交付、钢构防腐与地坪实拍', Icons.photo_library_outlined),
];

const salesSystems = <Map<String, String>>[
  {
    'title': '经济型室内防护',
    'use': '室内普通钢架、设备、门框、农机和低腐蚀金属件。',
    'system': '醇酸防锈漆或醇酸底漆 + 醇酸调合漆或醇酸磁漆',
    'note': '无腐蚀条件时不升级环氧或聚氨酯。'
  },
  {
    'title': '预算型户外耐候',
    'use': '预算有限的一般户外护栏、厂房构件和普通设备。',
    'system': '丙烯酸底漆 + 丙烯酸面漆',
    'note': '比醇酸更适合户外，沿海长寿命项目需升级。'
  },
  {
    'title': '室内环氧防腐',
    'use': '室内潮湿、凝露、油污或轻酸碱环境。',
    'system': '环氧底漆 + 环氧面漆',
    'note': '环氧面漆不用于长期日晒。'
  },
  {
    'title': '地坪系统',
    'use': '车间、车库、仓库、实验室与商业空间。',
    'system': '环氧地坪底漆 + 中间层 + 面漆或自流平',
    'note': '先确认基层强度、含水率、裂缝和载荷。'
  },
  {
    'title': '埋地与浸没',
    'use': '埋地管道、水下构件、污水设施与地下空间。',
    'system': '厚浆型环氧煤沥青或环氧煤沥青玻璃鳞片体系',
    'note': '饮用水、介质浸泡和高温必须专项确认。'
  },
  {
    'title': '户外高性能体系',
    'use': '桥梁、储罐外壁、工程机械与出口设备。',
    'system': '环氧富锌底漆 + 环氧云铁中间漆 + 丙烯酸聚氨酯面漆',
    'note': '长期户外优先脂肪族聚氨酯。'
  },
  {
    'title': '长寿命氟碳',
    'use': '沿海桥梁、港口、风电、幕墙和地标建筑。',
    'system': '配套底/中涂 + 氟碳面漆',
    'note': '仅在客户确有长寿命和高耐候需求时推荐。'
  },
  {
    'title': '耐高温',
    'use': '锅炉、烟囱、热风管、窑炉与冶金设备。',
    'system': '有机硅耐高温漆',
    'note': '按连续工作温度选择等级，不盲目选最高档。'
  },
  {
    'title': '水性环保体系',
    'use': '低气味、低 VOC 或通风受限项目。',
    'system': '水性醇酸、水性环氧或水性聚氨酯体系',
    'note': '食品直接接触与饮用水仍需专项合规文件。'
  },
];

const englishTemplates = <Map<String, String>>[
  {
    'title': '首次澄清需求',
    'text':
        'To recommend the most cost-effective coating system, please confirm: indoor or outdoor; substrate; corrosive media or immersion; operating temperature; expected service life; low-VOC requirement; colour and gloss.'
  },
  {
    'title': '经济方案说明',
    'text':
        'For a normal indoor and non-corrosive condition, we recommend an economical alkyd system. It provides the required protection without unnecessary cost.'
  },
  {
    'title': '户外寿命升级',
    'text':
        'For outdoor exposure, acrylic polyurethane offers a practical balance of weather resistance, gloss retention and cost. Coastal salt spray or a longer maintenance interval may require aliphatic polyurethane or fluorocarbon.'
  },
  {
    'title': '技术确认提醒',
    'text':
        'The proposed system is preliminary because the chemical concentration, temperature and immersion cycle have not yet been confirmed. Please provide these conditions before final specification.'
  },
  {
    'title': '环保合规提醒',
    'text':
        'For low-VOC or regulated projects, we can propose a waterborne system. Final compliance must be checked against destination-market requirements and product documentation.'
  },
];
