import 'package:flutter/material.dart';
import 'advisor/advisor_page.dart';
import 'catalog/catalog_item.dart';
import 'catalog/catalog_page.dart';
import 'catalog/catalog_repository.dart';
import 'home/home_page.dart';
import 'library/library_page.dart';
import 'theme/app_theme.dart';

class YongxingApp extends StatelessWidget {
  const YongxingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '永兴涂料',
      theme: buildAppTheme(),
      home: const CatalogLoader());
}

class CatalogLoader extends StatefulWidget {
  const CatalogLoader({super.key});
  @override
  State<CatalogLoader> createState() => _CatalogLoaderState();
}

class _CatalogLoaderState extends State<CatalogLoader> {
  late Future<List<CatalogItem>> future;
  @override
  void initState() {
    super.initState();
    future = const CatalogRepository().load();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<CatalogItem>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Scaffold(
                body: Center(child: CircularProgressIndicator()));
          }
          if (snapshot.hasError) {
            return _error(snapshot.error.toString());
          }
          return AppShell(items: snapshot.data!);
        },
      );

  Widget _error(String message) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.error_outline, size: 42, color: brandTeal),
              const SizedBox(height: 12),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 14),
              FilledButton(
                  onPressed: () =>
                      setState(() => future = const CatalogRepository().load()),
                  child: const Text('重新读取'))
            ]),
          ),
        ),
      );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.items});
  final List<CatalogItem> items;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  String? selectedSeries;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomePage(
          items: widget.items,
          onCatalog: () => _goCatalog(),
          onAdvisor: () => setState(() => index = 2),
          onSeries: _goSeries),
      CatalogPage(
          key: ValueKey(selectedSeries),
          items: widget.items,
          initialSeries: selectedSeries),
      AdvisorPage(items: widget.items),
      LibraryPage(items: widget.items),
    ];
    const titles = ['永兴涂料', '产品目录', '智能选型', '资料中心'];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                  color: brandTeal, borderRadius: BorderRadius.circular(8)),
              alignment: Alignment.center,
              child: const Text('Y',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w900))),
          const SizedBox(width: 10),
          Text(titles[index])
        ]),
        actions: [
          IconButton(
              tooltip: '关于',
              onPressed: () => showAboutDialog(
                  context: context,
                  applicationName: '永兴涂料应用',
                  applicationVersion: '1.3.0',
                  children: [const Text('培训与海外销售辅助工具。产品选型结论需结合真实工况复核。')]),
              icon: const Icon(Icons.info_outline))
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        height: 68,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: '首页'),
          NavigationDestination(
              icon: Icon(Icons.menu_book_outlined),
              selectedIcon: Icon(Icons.menu_book),
              label: '产品'),
          NavigationDestination(
              icon: Icon(Icons.auto_awesome_outlined),
              selectedIcon: Icon(Icons.auto_awesome),
              label: '智能选型'),
          NavigationDestination(
              icon: Icon(Icons.folder_outlined),
              selectedIcon: Icon(Icons.folder),
              label: '资料'),
        ],
      ),
    );
  }

  void _goCatalog() => setState(() {
        selectedSeries = null;
        index = 1;
      });
  void _goSeries(String value) => setState(() {
        selectedSeries = value;
        index = 1;
      });
}
