import 'package:flutter/material.dart';

const brandTeal = Color(0xff156b73);
const appInk = Color(0xff18232d);
const appMuted = Color(0xff667680);
const appLine = Color(0xffdfe5e9);
const appBackground = Color(0xfff4f6f8);

ThemeData buildAppTheme() {
  final scheme =
      ColorScheme.fromSeed(seedColor: brandTeal, brightness: Brightness.light);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme.copyWith(primary: brandTeal, surface: Colors.white),
    scaffoldBackgroundColor: appBackground,
    appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: appInk,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
        elevation: 0,
        titleTextStyle: TextStyle(
            color: appInk, fontSize: 19, fontWeight: FontWeight.w800)),
    cardTheme: const CardTheme(
        elevation: 0,
        margin: EdgeInsets.zero,
        color: Colors.white,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            side: BorderSide(color: appLine))),
    inputDecorationTheme: const InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(color: appLine)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(color: appLine)),
        contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 13)),
    filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            minimumSize: const Size(0, 48))),
  );
}
