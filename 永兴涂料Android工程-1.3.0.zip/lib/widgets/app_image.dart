import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class AppImage extends StatelessWidget {
  const AppImage(this.asset,
      {super.key,
      this.height,
      this.width,
      this.fit = BoxFit.cover,
      this.borderRadius = 8});
  final String asset;
  final double? height;
  final double? width;
  final BoxFit fit;
  final double borderRadius;
  @override
  Widget build(BuildContext context) => ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: Image.asset(asset,
          height: height,
          width: width,
          fit: fit,
          errorBuilder: (_, __, ___) => Container(
              height: height,
              width: width,
              color: const Color(0xffe7f1f0),
              alignment: Alignment.center,
              child: const Icon(Icons.image_not_supported_outlined,
                  color: brandTeal))));
}
