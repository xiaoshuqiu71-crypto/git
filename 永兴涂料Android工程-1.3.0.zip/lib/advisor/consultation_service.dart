import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../catalog/catalog_item.dart';

class ConsultationSettings {
  const ConsultationSettings(
      {required this.baseUrl, required this.model, required this.configured});
  final String baseUrl;
  final String model;
  final bool configured;
}

class ConsultationService {
  ConsultationService({http.Client? client})
      : _client = client ?? http.Client();
  static const _storage = FlutterSecureStorage();
  final http.Client _client;

  Future<ConsultationSettings> readSettings() async => ConsultationSettings(
      baseUrl: await _storage.read(key: 'apiUrl') ??
          'https://rkapi.com/v1/chat/completions',
      model: await _storage.read(key: 'apiModel') ?? 'gpt-5.6-terra',
      configured: ((await _storage.read(key: 'apiKey'))?.isNotEmpty ?? false));

  Future<void> saveSettings(
      {required String baseUrl,
      required String model,
      required String apiKey}) async {
    if (!baseUrl.trim().startsWith('https://'))
      throw Exception('API 地址必须以 https:// 开头。');
    if (model.trim().isEmpty) throw Exception('请填写模型名。');
    await _storage.write(key: 'apiUrl', value: baseUrl.trim());
    await _storage.write(key: 'apiModel', value: model.trim());
    if (apiKey.trim().isNotEmpty)
      await _storage.write(key: 'apiKey', value: apiKey.trim());
  }

  Future<Map<String, dynamic>> ask(
      String scenario, List<CatalogItem> items) async {
    final settings = await readSettings();
    final apiKey = await _storage.read(key: 'apiKey');
    if (apiKey == null || apiKey.isEmpty)
      throw Exception('尚未配置 API Key。请先打开设置。');
    final catalog = items
        .where((x) => x.isProduct)
        .map((x) => '${x.name}: ${x.usage}')
        .join('\n');
    final prompt =
        '你是工业涂料选型助手。不要要求用户先回答问题；先完整列出描述中可能涉及的涂装部位，再给每个部位候选体系。产品名称只能使用正式目录中的完整中文名称。民用家装、食品直接接触、饮用水、强酸碱或长期浸泡必须标记为“必须确认”。遵循够用就好。\n\n正式产品目录：$catalog\n\n用户描述：$scenario\n\n只返回 JSON：{"summary":"...","applications":[{"name":"部位","status":"优先考虑|可能涉及|必须确认","system":"体系","models":["正式产品名称"],"assumptions":"假设","missing":["需确认信息"],"notes":"说明"}]}';
    final response = await _client
        .post(Uri.parse(settings.baseUrl),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $apiKey'
            },
            body: jsonEncode({
              'model': settings.model,
              'temperature': .2,
              'response_format': {'type': 'json_object'},
              'messages': [
                {'role': 'system', 'content': '你是严谨的工业涂料技术支持。'},
                {'role': 'user', 'content': prompt}
              ]
            }))
        .timeout(const Duration(seconds: 120),
            onTimeout: () => throw Exception('在线咨询超时，请检查网络后重试。'));
    if (response.statusCode < 200 || response.statusCode >= 300)
      throw Exception('服务返回 ${response.statusCode}，请检查 API 地址、模型名和 Key。');
    final content = (jsonDecode(response.body)
        as Map<String, dynamic>)['choices']?[0]?['message']?['content'];
    if (content is! String) throw Exception('在线咨询服务没有返回内容。');
    try {
      return jsonDecode(content) as Map<String, dynamic>;
    } catch (_) {
      throw Exception('在线咨询返回格式无法识别，请重试。');
    }
  }
}
