import 'package:flutter/material.dart';
import '../catalog/catalog_item.dart';
import '../theme/app_theme.dart';
import 'consultation_page.dart';
import 'offline_selection_page.dart';

class AdvisorPage extends StatelessWidget {
  const AdvisorPage({super.key, required this.items});
  final List<CatalogItem> items;
  @override
  Widget build(BuildContext context) =>
      ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 28), children: [
        const Text('从客户描述到候选体系',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        const Text('不了解专业术语也可以直接输入行业或空间。系统先列出可能部位，再给出适用范围与必须确认项。',
            style: TextStyle(height: 1.6, color: appMuted)),
        const SizedBox(height: 18),
        _entry(context,
            title: '在线场景咨询',
            description: '理解任意行业、民用空间、构件和工况，需要网络与 API。',
            icon: Icons.auto_awesome_outlined,
            primary: true,
            page: ConsultationPage(items: items)),
        const SizedBox(height: 12),
        _entry(context,
            title: '离线场景库',
            description: '无网络时浏览常见体系、适用条件和风险边界。',
            icon: Icons.psychology_outlined,
            primary: false,
            page: const OfflineSelectionPage()),
        const SizedBox(height: 22),
        const Text('推荐原则',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('先满足真实工况和预算，再考虑寿命升级。资料未覆盖、强酸碱、长期浸泡、饮用水及食品直接接触不会给出确定现货结论。',
            style: TextStyle(height: 1.65, color: appMuted)),
      ]);
  Widget _entry(BuildContext context,
          {required String title,
          required String description,
          required IconData icon,
          required bool primary,
          required Widget page}) =>
      Card(
          color: primary ? brandTeal : Colors.white,
          child: InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => page)),
              child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                            color: primary
                                ? Colors.white.withOpacity(.14)
                                : const Color(0xffe7f1f0),
                            borderRadius: BorderRadius.circular(8)),
                        child: Icon(icon,
                            color: primary ? Colors.white : brandTeal)),
                    const SizedBox(width: 13),
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text(title,
                              style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: primary ? Colors.white : appInk)),
                          const SizedBox(height: 5),
                          Text(description,
                              style: TextStyle(
                                  height: 1.45,
                                  color: primary ? Colors.white70 : appMuted))
                        ])),
                    Icon(Icons.chevron_right,
                        color: primary ? Colors.white : appMuted)
                  ]))));
}
