const restrictedWords = <String>[
  '居民',
  '住宅',
  '家装',
  '厨房',
  '卫生间',
  '卧室',
  '客厅',
  '儿童',
  '食品接触',
  '饮用水',
  '餐具',
  '持续浸泡',
  '强酸',
  '强碱',
  '氰化',
  '电镀'
];

class ConsultationApplication {
  const ConsultationApplication(
      {required this.name,
      required this.status,
      required this.system,
      required this.models,
      required this.assumptions,
      required this.missing,
      required this.notes});
  final String name;
  final String status;
  final String system;
  final List<String> models;
  final String assumptions;
  final List<String> missing;
  final String notes;
}

class ConsultationResult {
  const ConsultationResult({required this.summary, required this.applications});
  final String summary;
  final List<ConsultationApplication> applications;
}

ConsultationResult guardConsultation(Map<String, dynamic> raw,
    {required String scenario, required Set<String> allowedProducts}) {
  final source = raw['applications'] is List
      ? raw['applications'] as List
      : const <dynamic>[];
  final applications = <ConsultationApplication>[];
  for (final entry in source.take(12)) {
    if (entry is! Map) continue;
    final x = entry.cast<String, dynamic>();
    final name = x['name']?.toString() ?? '候选涂装部位';
    final context =
        '$scenario $name ${x['notes'] ?? ''} ${x['assumptions'] ?? ''}';
    final restricted = restrictedWords.any(context.contains);
    final models = ((x['models'] as List?) ?? const [])
        .map((v) => v.toString())
        .where(allowedProducts.contains)
        .toList();
    final status = restricted || models.isEmpty || x['status'] == '必须确认'
        ? '必须确认'
        : (x['status'] == '优先考虑' ? '优先考虑' : '可能涉及');
    applications.add(ConsultationApplication(
      name: name,
      status: status,
      system: x['system']?.toString() ?? '待技术确认的涂装体系',
      models: status == '必须确认' ? const ['专项技术确认'] : models,
      assumptions: x['assumptions']?.toString() ?? '未取得完整基材、介质和施工条件。',
      missing: ((x['missing'] as List?) ?? const ['基材与现有漆层'])
          .take(5)
          .map((v) => v.toString())
          .toList(),
      notes: restricted
          ? '现有资料未覆盖此类用途或风险边界，请由技术人员确认。'
          : x['notes']?.toString() ?? '施工前请确认表面处理和完整底中面配套。',
    ));
  }
  return ConsultationResult(
      summary: raw['summary']?.toString() ?? '已按描述列出可能需要涂装的部位。',
      applications: applications);
}
