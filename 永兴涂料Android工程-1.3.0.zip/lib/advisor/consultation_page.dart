import 'package:flutter/material.dart';
import '../catalog/catalog_item.dart';
import '../theme/app_theme.dart';
import 'consultation_guard.dart';
import 'consultation_service.dart';

class ConsultationPage extends StatefulWidget {
  const ConsultationPage({super.key, required this.items});
  final List<CatalogItem> items;
  @override
  State<ConsultationPage> createState() => _ConsultationPageState();
}

class _ConsultationPageState extends State<ConsultationPage> {
  final scenario = TextEditingController();
  final service = ConsultationService();
  bool busy = false;
  String? error;
  ConsultationResult? answer;
  @override
  void dispose() {
    scenario.dispose();
    super.dispose();
  }

  Future<void> ask() async {
    if (scenario.text.trim().isEmpty) {
      setState(() => error = '请输入客户描述或使用场景。');
      return;
    }
    setState(() {
      busy = true;
      error = null;
      answer = null;
    });
    try {
      final raw = await service.ask(scenario.text.trim(), widget.items);
      final allowed =
          widget.items.where((x) => x.isProduct).map((x) => x.name).toSet();
      if (mounted)
        setState(() => answer = guardConsultation(raw,
            scenario: scenario.text, allowedProducts: allowed));
    } catch (e) {
      if (mounted)
        setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> configure() async {
    final settings = await service.readSettings();
    if (!mounted) return;
    final url = TextEditingController(text: settings.baseUrl),
        model = TextEditingController(text: settings.model),
        key = TextEditingController();
    await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
                title: const Text('在线咨询设置'),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: url,
                      decoration: const InputDecoration(labelText: 'API 地址')),
                  const SizedBox(height: 10),
                  TextField(
                      controller: model,
                      decoration: const InputDecoration(labelText: '模型名')),
                  const SizedBox(height: 10),
                  TextField(
                      controller: key,
                      obscureText: true,
                      decoration: InputDecoration(
                          labelText: 'API Key',
                          hintText: settings.configured ? '已保存；留空不修改' : '请填写'))
                ])),
                actions: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('取消')),
                  FilledButton(
                      onPressed: () async {
                        try {
                          await service.saveSettings(
                              baseUrl: url.text,
                              model: model.text,
                              apiKey: key.text);
                          if (context.mounted) Navigator.pop(context);
                        } catch (e) {
                          if (context.mounted)
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text(e
                                    .toString()
                                    .replaceFirst('Exception: ', ''))));
                        }
                      },
                      child: const Text('保存'))
                ]));
    url.dispose();
    model.dispose();
    key.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final grouped = <String, List<ConsultationApplication>>{
      '优先考虑': [],
      '可能涉及': [],
      '必须确认': []
    };
    for (final item in answer?.applications ?? const []) {
      grouped[item.status]?.add(item);
    }
    return Scaffold(
        appBar: AppBar(title: const Text('在线场景咨询'), actions: [
          IconButton(
              tooltip: '设置 API',
              onPressed: configure,
              icon: const Icon(Icons.settings_outlined))
        ]),
        body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              const Text('把客户原话直接输入',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 7),
              const Text('模型会先拆解可能涉及的全部涂装部位，再按正式产品目录给出候选体系。',
                  style: TextStyle(height: 1.6, color: appMuted)),
              const SizedBox(height: 14),
              TextField(
                  controller: scenario,
                  minLines: 5,
                  maxLines: 8,
                  decoration: const InputDecoration(
                      hintText: '例如：炼金厂需要做防腐；海边酒店栏杆；普通居民厨房翻新')),
              const SizedBox(height: 12),
              FilledButton.icon(
                  onPressed: busy ? null : ask,
                  icon: busy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.auto_awesome),
                  label: Text(busy ? '正在理解场景…' : '开始智能分析')),
              if (error != null)
                Container(
                    margin: const EdgeInsets.only(top: 12),
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                        color: const Color(0xfffff3df),
                        borderRadius: BorderRadius.circular(8)),
                    child: Text('$error\n输入内容已保留，可检查设置后重试。',
                        style: const TextStyle(height: 1.5))),
              if (answer != null) ...[
                const SizedBox(height: 18),
                Text(answer!.summary,
                    style: const TextStyle(
                        height: 1.65, fontWeight: FontWeight.w600)),
                ...grouped.entries
                    .where((x) => x.value.isNotEmpty)
                    .map((group) => _group(group.key, group.value))
              ],
            ]));
  }

  Widget _group(String title, List<ConsultationApplication> values) => Padding(
      padding: const EdgeInsets.only(top: 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: title == '必须确认' ? const Color(0xff915a18) : brandTeal)),
        const SizedBox(height: 8),
        ...values.map((item) => Padding(
            padding: const EdgeInsets.only(bottom: 9),
            child: Card(
                child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.name,
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 5),
                          Text(item.system,
                              style: const TextStyle(
                                  color: brandTeal,
                                  fontWeight: FontWeight.w700)),
                          const SizedBox(height: 5),
                          Text(item.models.join(' + ')),
                          const SizedBox(height: 8),
                          Text('判断依据：${item.assumptions}',
                              style: const TextStyle(
                                  height: 1.45, color: appMuted)),
                          Text('仍需确认：${item.missing.join('、')}',
                              style: const TextStyle(
                                  height: 1.45, color: appMuted)),
                          const SizedBox(height: 5),
                          Text(item.notes, style: const TextStyle(height: 1.5))
                        ])))))
      ]));
}
