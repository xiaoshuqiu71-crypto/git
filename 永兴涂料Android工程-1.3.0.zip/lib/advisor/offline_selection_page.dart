import 'package:flutter/material.dart';
import '../library/library_content.dart';
import '../theme/app_theme.dart';

class OfflineSelectionPage extends StatefulWidget {
  const OfflineSelectionPage({super.key});
  @override
  State<OfflineSelectionPage> createState() => _OfflineSelectionPageState();
}

class _OfflineSelectionPageState extends State<OfflineSelectionPage> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final words = query
        .trim()
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .toList();
    final matches = words.isEmpty
        ? salesSystems
        : salesSystems.where((item) {
            final text = item.values.join(' ');
            return words.any(text.contains);
          }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('离线场景库')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('无网络也能查常见工况',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
          const SizedBox(height: 7),
          const Text('输入行业、部位或条件，例如“炼金厂 地坪 酸碱”。结果只作候选范围，复杂介质仍需技术确认。',
              style: TextStyle(height: 1.6, color: appMuted)),
          const SizedBox(height: 14),
          TextField(
              onChanged: (value) => setState(() => query = value),
              decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search), hintText: '行业、部位、腐蚀或寿命要求')),
          const SizedBox(height: 14),
          if (matches.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Text('离线库未找到直接匹配。可在联网后使用在线场景咨询，让模型先拆解全部可能涂装部位。',
                  textAlign: TextAlign.center,
                  style: TextStyle(height: 1.6, color: appMuted)),
            ),
          for (final item in matches)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item['title']!,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      Text(item['use']!, style: const TextStyle(height: 1.5)),
                      const SizedBox(height: 6),
                      Text(item['system']!,
                          style: const TextStyle(
                              height: 1.5,
                              color: brandTeal,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      Text(item['note']!,
                          style: const TextStyle(height: 1.5, color: appMuted)),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
