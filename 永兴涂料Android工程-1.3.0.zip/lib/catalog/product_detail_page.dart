import 'package:flutter/material.dart';
import '../library/color_card_page.dart';
import '../theme/app_theme.dart';
import '../widgets/app_image.dart';
import 'catalog_item.dart';

class ProductDetailPage extends StatelessWidget {
  const ProductDetailPage({super.key, required this.item});
  final CatalogItem item;
  String get image => item.name.contains('地坪')
      ? 'assets/portfolio/floor-green.jpg'
      : item.name.contains('富锌') || item.name.contains('钢')
          ? 'assets/portfolio/steel-coating.jpg'
          : 'assets/portfolio/product-range.jpg';
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(item.isProduct ? '产品详情' : '资料详情')),
        body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
            children: [
              AppImage(image, height: 176, width: double.infinity),
              const SizedBox(height: 18),
              Text(item.series,
                  style: const TextStyle(
                      color: brandTeal,
                      fontSize: 12,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(item.name,
                  style: const TextStyle(
                      fontSize: 25,
                      height: 1.25,
                      fontWeight: FontWeight.w800,
                      color: appInk)),
              if (item.usage.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(item.usage,
                    style: const TextStyle(
                        fontSize: 15, height: 1.7, color: appMuted))
              ],
              const SizedBox(height: 10),
              ...item.sections.entries.map((entry) =>
                  _DetailSection(title: entry.key, text: entry.value)),
              if (item.isProduct) ...[
                const _DetailSection(
                    title: '产品证书',
                    text:
                        '公司产品可配套提供 RoHS 欧盟符合性资料；适用产品范围及出口合规结论须以证书原件、批次和目的地要求为准。'),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const ColorCardPage())),
                    icon: const Icon(Icons.palette_outlined),
                    label: const Text('查看可选颜色与使用边界')),
              ],
            ]),
      );
}

class _DetailSection extends StatelessWidget {
  const _DetailSection({required this.title, required this.text});
  final String title;
  final String text;
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.only(top: 16, bottom: 4),
      margin: const EdgeInsets.only(top: 8),
      decoration:
          const BoxDecoration(border: Border(top: BorderSide(color: appLine))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title,
            style: const TextStyle(
                fontSize: 15, fontWeight: FontWeight.w800, color: brandTeal)),
        const SizedBox(height: 8),
        SelectableText(text,
            style: const TextStyle(fontSize: 14, height: 1.7, color: appInk))
      ]));
}
