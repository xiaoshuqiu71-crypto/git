import 'catalog_item.dart';

List<CatalogItem> filterCatalog(List<CatalogItem> items,
    {String query = '', CatalogType? type, String? series}) {
  final needle = query.trim().toLowerCase();
  return items.where((item) {
    if (type != null && item.type != type) {
      return false;
    }
    if (series != null && series.isNotEmpty && item.series != series) {
      return false;
    }
    return needle.isEmpty || item.searchableText.contains(needle);
  }).toList(growable: false);
}
