import 'dart:convert';
import 'package:flutter/services.dart';
import 'catalog_item.dart';

class CatalogLoadException implements Exception {
  const CatalogLoadException(this.message);
  final String message;
  @override
  String toString() => message;
}

class CatalogRepository {
  const CatalogRepository();
  Future<List<CatalogItem>> load() async {
    try {
      final raw = await rootBundle.loadString('assets/data-products.json');
      final decoded = jsonDecode(raw);
      if (decoded is! List) throw const FormatException('根节点不是列表');
      return decoded
          .map((value) =>
              CatalogItem.fromJson((value as Map).cast<String, dynamic>()))
          .toList(growable: false);
    } catch (_) {
      throw const CatalogLoadException('本地产品资料无法读取，请重新安装完整应用。');
    }
  }
}
