import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'catalog_filter.dart';
import 'catalog_item.dart';
import 'product_detail_page.dart';

class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key, required this.items, this.initialSeries});
  final List<CatalogItem> items;
  final String? initialSeries;
  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  String query = '';
  CatalogType? type;
  String? series;

  @override
  void initState() {
    super.initState();
    series = widget.initialSeries;
  }

  @override
  Widget build(BuildContext context) {
    final seriesNames = widget.items
        .where((item) => item.isProduct)
        .map((item) => item.series)
        .toSet()
        .toList()
      ..sort();
    final results =
        filterCatalog(widget.items, query: query, type: type, series: series);
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: TextField(
                onChanged: (value) => setState(() => query = value),
                decoration: const InputDecoration(
                    hintText: '搜索产品名称、用途、特性或施工信息',
                    prefixIcon: Icon(Icons.search))),
          ),
        ),
        SliverToBoxAdapter(child: _typeFilters()),
        if (type != CatalogType.reference)
          SliverToBoxAdapter(child: _seriesFilters(seriesNames)),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
            child: Row(
              children: [
                Text('${results.length} 条结果',
                    style: const TextStyle(color: appMuted)),
                const Spacer(),
                if (query.isNotEmpty || type != null || series != null)
                  TextButton(onPressed: _clear, child: const Text('清除筛选')),
              ],
            ),
          ),
        ),
        if (results.isEmpty)
          const SliverFillRemaining(
              hasScrollBody: false,
              child: Center(
                  child: Text('没有找到匹配资料\n请更换关键词或清除筛选',
                      textAlign: TextAlign.center,
                      style: TextStyle(height: 1.7, color: appMuted))))
        else
          SliverList.builder(
              itemCount: results.length,
              itemBuilder: (context, index) =>
                  _resultRow(context, results[index])),
        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }

  Widget _typeFilters() => SizedBox(
        height: 44,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [
            _filter('全部', type == null, () => setState(() => type = null)),
            _filter('公司产品', type == CatalogType.product,
                () => setState(() => type = CatalogType.product)),
            _filter('施工与证书', type == CatalogType.reference,
                () => setState(() => type = CatalogType.reference)),
          ],
        ),
      );

  Widget _seriesFilters(List<String> names) => SizedBox(
        height: 44,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [
            _filter(
                '全部系列', series == null, () => setState(() => series = null)),
            for (final name in names)
              _filter(
                  name, series == name, () => setState(() => series = name)),
          ],
        ),
      );

  Widget _filter(String label, bool selected, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
            label: Text(label),
            selected: selected,
            onSelected: (_) => onTap(),
            showCheckmark: false,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(6))),
      );

  Widget _resultRow(BuildContext context, CatalogItem item) => Material(
        color: Colors.white,
        child: InkWell(
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => ProductDetailPage(item: item))),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 15, 12, 15),
            decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: appLine))),
            child: Row(
              children: [
                Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                        color: const Color(0xffe7f1f0),
                        borderRadius: BorderRadius.circular(7)),
                    child: Icon(
                        item.isProduct
                            ? Icons.format_paint_outlined
                            : Icons.menu_book_outlined,
                        color: brandTeal)),
                const SizedBox(width: 13),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text(item.name,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 16,
                              height: 1.35,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text(item.isProduct ? item.series : item.usage,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 12, height: 1.4, color: appMuted))
                    ])),
                const Icon(Icons.chevron_right, color: appMuted),
              ],
            ),
          ),
        ),
      );

  void _clear() => setState(() {
        query = '';
        type = null;
        series = null;
      });
}
