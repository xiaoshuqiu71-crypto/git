enum CatalogType { product, reference }

class CatalogItem {
  const CatalogItem(
      {required this.id,
      required this.type,
      required this.name,
      required this.series,
      required this.usage,
      required this.sections});

  factory CatalogItem.fromJson(Map<String, dynamic> json) {
    final name = json['name']?.toString().trim() ?? '';
    if (name.isEmpty) throw const FormatException('资料名称不能为空');
    final rawSections = json['sections'];
    return CatalogItem(
      id: json['id']?.toString() ?? name,
      type: json['type'] == 'product'
          ? CatalogType.product
          : CatalogType.reference,
      name: name,
      series: json['series']?.toString() ??
          (json['type'] == 'product' ? '其他系列' : '资料与证书'),
      usage: json['usage']?.toString() ?? '',
      sections: rawSections is Map
          ? rawSections
              .map((key, value) => MapEntry(key.toString(), value.toString()))
          : const {},
    );
  }

  final String id;
  final CatalogType type;
  final String name;
  final String series;
  final String usage;
  final Map<String, String> sections;
  bool get isProduct => type == CatalogType.product;
  String get searchableText =>
      '$name $series $usage ${sections.entries.map((e) => '${e.key} ${e.value}').join(' ')}'
          .toLowerCase();
}
