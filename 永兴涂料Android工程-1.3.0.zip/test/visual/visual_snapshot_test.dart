import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yongxing_coatings_mobile/app.dart';
import 'package:yongxing_coatings_mobile/catalog/catalog_repository.dart';
import 'package:yongxing_coatings_mobile/theme/app_theme.dart';

void main() {
  testWidgets('renders the four main mobile destinations at 393x873',
      (tester) async {
    await tester.binding.setSurfaceSize(const Size(393, 873));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetDevicePixelRatio);

    final items = await const CatalogRepository().load();
    const captureKey = ValueKey('visual-capture');
    await tester.pumpWidget(MaterialApp(
      theme: buildAppTheme(),
      home: RepaintBoundary(
        key: captureKey,
        child: AppShell(items: items),
      ),
    ));
    await tester.pumpAndSettle();

    await _save(tester, captureKey, 'home');
    for (final destination in ['产品', '智能选型', '资料']) {
      await tester.tap(find.text(destination).last);
      await tester.pumpAndSettle();
      await _save(
          tester,
          captureKey,
          destination == '产品'
              ? 'catalog'
              : destination == '智能选型'
                  ? 'advisor'
                  : 'library');
    }
    expect(tester.takeException(), isNull);
  });
}

Future<void> _save(WidgetTester tester, Key key, String name) async {
  final boundary = tester.renderObject<RenderRepaintBoundary>(find.byKey(key));
  final image = await boundary.toImage(pixelRatio: 1);
  final data = await image.toByteData(format: ui.ImageByteFormat.png);
  if (data == null) throw StateError('无法生成界面截图');
  final directory = Directory('build/visual')..createSync(recursive: true);
  File('${directory.path}/$name.png')
      .writeAsBytesSync(data.buffer.asUint8List());
}
