import 'package:flutter_test/flutter_test.dart';
import 'package:yongxing_coatings_mobile/advisor/consultation_guard.dart';

void main() {
  const allowed = {'环氧富锌底漆', '丙烯酸聚氨酯面漆'};

  test('removes invented products from consultation output', () {
    final result = guardConsultation(
      {
        'summary': 'test',
        'applications': [
          {
            'name': '室外钢构',
            'status': '优先考虑',
            'system': '防腐体系',
            'models': ['环氧富锌底漆', '不存在的产品'],
            'assumptions': '一般大气',
            'missing': ['寿命'],
            'notes': '确认表面处理',
          },
        ],
      },
      scenario: '室外钢构',
      allowedProducts: allowed,
    );

    expect(result.applications.single.models, ['环氧富锌底漆']);
  });

  test('forces residential and food-contact scenarios to technical review', () {
    final result = guardConsultation(
      {
        'applications': [
          {
            'name': '厨房台面',
            'status': '优先考虑',
            'system': '面漆',
            'models': ['丙烯酸聚氨酯面漆'],
            'missing': [],
          },
        ],
      },
      scenario: '居民厨房',
      allowedProducts: allowed,
    );

    expect(result.applications.single.status, '必须确认');
    expect(result.applications.single.models, ['专项技术确认']);
  });
}
