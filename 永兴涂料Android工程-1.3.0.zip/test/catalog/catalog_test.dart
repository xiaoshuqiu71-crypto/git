import 'package:flutter_test/flutter_test.dart';
import 'package:yongxing_coatings_mobile/catalog/catalog_filter.dart';
import 'package:yongxing_coatings_mobile/catalog/catalog_item.dart';

void main() {
  final products = <CatalogItem>[
    const CatalogItem(
      id: '1',
      type: CatalogType.product,
      name: '环氧富锌底漆',
      series: '环氧系列',
      usage: '钢结构防腐打底',
      sections: {'主要特性': '附着力好'},
    ),
    const CatalogItem(
      id: '2',
      type: CatalogType.reference,
      name: 'RoHS 证书',
      series: '资料与证书',
      usage: '欧盟符合性资料',
      sections: {'使用说明': '以证书原件为准'},
    ),
  ];

  test('searches names, usage, and detail sections', () {
    expect(filterCatalog(products, query: '附着力'), [products.first]);
    expect(filterCatalog(products, query: '钢结构'), [products.first]);
    expect(filterCatalog(products, query: 'RoHS'), [products.last]);
  });

  test('combines type and series filters', () {
    expect(
      filterCatalog(
        products,
        type: CatalogType.product,
        series: '环氧系列',
      ),
      [products.first],
    );
    expect(
      filterCatalog(products, type: CatalogType.reference),
      [products.last],
    );
  });
}
