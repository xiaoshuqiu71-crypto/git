import 'package:flutter_test/flutter_test.dart';
import 'package:yongxing_coatings_mobile/library/library_content.dart';

void main() {
  test('contains every desktop 0.1.8 sales and reference entry', () {
    const required = {
      '海外销售选型库',
      '英文沟通模板',
      '在线场景咨询',
      '离线场景库',
      '比色卡',
      '技术说明书',
      '施工工艺',
      '施工方案',
      'RoHS 证书',
      '工程案例',
    };

    expect(libraryEntries.map((entry) => entry.title).toSet(),
        containsAll(required));
    expect(
        libraryEntries.every((entry) => entry.description.isNotEmpty), isTrue);
  });
}
