import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yongxing_coatings_mobile/app.dart';

void main() {
  testWidgets('shows four stable mobile destinations', (tester) async {
    tester.view.physicalSize = const Size(360, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const YongxingApp());
    await tester.pumpAndSettle();

    for (final label in ['首页', '产品', '智能选型', '资料']) {
      expect(find.text(label), findsWidgets);
    }

    await tester.tap(find.text('资料').last);
    await tester.pumpAndSettle();
    expect(find.text('销售与资料中心'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
