import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const YongxingApp());

class YongxingApp extends StatelessWidget {
  const YongxingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: '永兴涂料',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xff0d6b5c), scaffoldBackgroundColor: const Color(0xfff5f7f6)),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> items = []; String query = ''; int tab = 0; bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final raw = await rootBundle.loadString('assets/data-products.json'); final data = (jsonDecode(raw) as List).cast<Map<String, dynamic>>(); setState(() { items = data; loading = false; }); }
  List<Map<String, dynamic>> get filtered {
    final docs = items.where((x) => tab == 0 || (tab == 1 ? x['type'] == 'product' : x['type'] != 'product')).toList();
    if (query.trim().isEmpty) return docs;
    final q = query.toLowerCase(); return docs.where((x) => '${x['name']} ${x['raw']} ${x['usage']}'.toLowerCase().contains(q)).toList();
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('永兴涂料', style: TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: '永兴涂料产品库', applicationVersion: '1.0.0'), icon: const Icon(Icons.info_outline))]),
    body: loading ? const Center(child: CircularProgressIndicator()) : CustomScrollView(slivers: [
      SliverToBoxAdapter(child: _hero()),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), child: TextField(onChanged: (v) => setState(() => query = v), decoration: InputDecoration(hintText: '搜索产品、用途、施工资料…', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))))),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('全部')), ButtonSegment(value: 1, label: Text('产品')), ButtonSegment(value: 2, label: Text('资料'))], selected: {tab}, onSelectionChanged: (s) => setState(() => tab = s.first)))),
      SliverPadding(padding: const EdgeInsets.all(16), sliver: SliverList(delegate: SliverChildBuilderDelegate((context, i) { final item = filtered[i]; return _card(item); }, childCount: filtered.length))),
    ]),
  );
  Widget _hero() => Container(height: 165, margin: const EdgeInsets.fromLTRB(16, 8, 16, 0), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xff0d6b5c), Color(0xff164b58)]), image: const DecorationImage(image: AssetImage('assets/brand-cover.png'), fit: BoxFit.cover, opacity: .24)), child: const Padding(padding: EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [Text('专业涂料产品库', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('产品 · 颜色 · 施工工艺 · 技术说明书', style: TextStyle(color: Colors.white70))])));
  Widget _card(Map<String, dynamic> x) { final sections = (x['sections'] as Map?)?.cast<String, dynamic>() ?? {}; final preview = sections.isNotEmpty ? sections.values.first.toString() : (x['usage']?.toString() ?? '点击查看详情'); return Card(margin: const EdgeInsets.only(bottom: 12), elevation: 0, child: InkWell(borderRadius: BorderRadius.circular(16), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: x))), child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(x['type'] == 'product' ? Icons.format_paint : Icons.menu_book)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${x['name'] ?? '未命名资料'}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 5), Text(preview, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade700))])), const Icon(Icons.chevron_right)])))); }
}

class DetailPage extends StatelessWidget { final Map<String, dynamic> item; const DetailPage({super.key, required this.item});
  @override Widget build(BuildContext context) { final sections = (item['sections'] as Map?)?.cast<String, dynamic>() ?? {}; return Scaffold(appBar: AppBar(title: Text(item['name']?.toString() ?? '资料详情')), body: ListView(padding: const EdgeInsets.all(18), children: [Text(item['name']?.toString() ?? '', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), if (item['usage'] != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(item['usage'].toString(), style: TextStyle(color: Colors.grey.shade700, fontSize: 16))), const SizedBox(height: 18), ...sections.entries.map((e) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.key, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)), const SizedBox(height: 8), SelectableText(e.value.toString(), style: const TextStyle(height: 1.5))]))))])); }
}
