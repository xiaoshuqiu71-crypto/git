import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

const _documentedModels = <String>{'YH-1','YH-3','YH-5','YH-10','YH-13','YH-15','YH-21','YH-22','YH-36','YH-42','YH-43','YH-44','YH-45','YH-47','YH-48','YH-50','YH-51','YH-53','YH-54','YH-55','YH-64','YH-65','YH-70','YH-71','YH-76','YH-78','YH-82','YH-86','YH-100','YH-101','YH-102','YH-103','YH-104','YH-105','YH-106','YH-107','YH-108','YH-111','YH-112','YH-116'};
const _restrictedWords = <String>['居民','住宅','家装','厨房','卫生间','卧室','客厅','儿童','食品接触','饮用水','餐具','持续浸泡','强酸','强碱','氰化','电镀'];

void main() => runApp(const YongxingApp());

class YongxingApp extends StatelessWidget {
  const YongxingApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner: false, title: '永兴涂料', theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xff0d6b5c), scaffoldBackgroundColor: const Color(0xfff5f7f6)), home: const HomePage());
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> items = []; String query = ''; int tab = 0; bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final raw = await rootBundle.loadString('assets/data-products.json'); final data = (jsonDecode(raw) as List).cast<Map<String, dynamic>>(); if (mounted) setState(() { items = data; loading = false; }); }
  List<Map<String, dynamic>> get filtered { final docs = items.where((x) => tab == 0 || (tab == 1 ? x['type'] == 'product' : x['type'] != 'product')).toList(); if (query.trim().isEmpty) return docs; final q = query.toLowerCase(); return docs.where((x) => '${x['name']} ${x['raw']} ${x['usage']}'.toLowerCase().contains(q)).toList(); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('永兴涂料', style: TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(tooltip: '在线场景咨询', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ConsultationPage(items: items))), icon: const Icon(Icons.auto_awesome_outlined)), IconButton(tooltip: '离线场景库', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SelectionPage())), icon: const Icon(Icons.psychology_outlined)), IconButton(onPressed: () => showAboutDialog(context: context, applicationName: '永兴涂料产品库', applicationVersion: '1.1.0'), icon: const Icon(Icons.info_outline))]),
    body: loading ? const Center(child: CircularProgressIndicator()) : CustomScrollView(slivers: [
      SliverToBoxAdapter(child: _hero()),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), child: TextField(onChanged: (v) => setState(() => query = v), decoration: InputDecoration(hintText: '搜索产品、用途、施工资料...', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))))),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('全部')), ButtonSegment(value: 1, label: Text('产品')), ButtonSegment(value: 2, label: Text('资料'))], selected: {tab}, onSelectionChanged: (s) => setState(() => tab = s.first)))),
      SliverPadding(padding: const EdgeInsets.all(16), sliver: SliverList(delegate: SliverChildBuilderDelegate((context, i) => _card(filtered[i]), childCount: filtered.length))),
    ]),
  );
  Widget _hero() => Container(height: 165, margin: const EdgeInsets.fromLTRB(16, 8, 16, 0), decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: const Color(0xff0d6b5c), image: const DecorationImage(image: AssetImage('assets/brand-cover.png'), fit: BoxFit.cover, opacity: .24)), child: const Padding(padding: EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [Text('专业涂料产品库', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('产品 · 颜色 · 施工工艺 · 在线场景咨询', style: TextStyle(color: Colors.white70))])));
  Widget _card(Map<String, dynamic> x) { final sections = (x['sections'] as Map?)?.cast<String, dynamic>() ?? {}; final preview = sections.isNotEmpty ? sections.values.first.toString() : (x['usage']?.toString() ?? '点击查看详情'); return Card(margin: const EdgeInsets.only(bottom: 12), elevation: 0, child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailPage(item: x))), child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(x['type'] == 'product' ? Icons.format_paint : Icons.menu_book)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${x['name'] ?? '未命名资料'}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 5), Text(preview, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade700))])), const Icon(Icons.chevron_right)])))); }
}

class DetailPage extends StatelessWidget { final Map<String, dynamic> item; const DetailPage({super.key, required this.item});
  @override Widget build(BuildContext context) { final sections = (item['sections'] as Map?)?.cast<String, dynamic>() ?? {}; return Scaffold(appBar: AppBar(title: Text(item['name']?.toString() ?? '资料详情')), body: ListView(padding: const EdgeInsets.all(18), children: [Text(item['name']?.toString() ?? '', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), if (item['usage'] != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(item['usage'].toString(), style: TextStyle(color: Colors.grey.shade700, fontSize: 16))), const SizedBox(height: 18), ...sections.entries.map((e) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.key, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)), const SizedBox(height: 8), SelectableText(e.value.toString(), style: const TextStyle(height: 1.5))]))))])); }
}

class ConsultationPage extends StatefulWidget { final List<Map<String, dynamic>> items; const ConsultationPage({super.key, required this.items}); @override State<ConsultationPage> createState() => _ConsultationPageState(); }
class _ConsultationPageState extends State<ConsultationPage> {
  final scenario = TextEditingController(); final service = _ConsultationService(); bool busy = false; String? error; Map<String, dynamic>? answer;
  @override void dispose() { scenario.dispose(); super.dispose(); }
  Future<void> _configure() async { final settings = await service.readSettings(); if (!mounted) return; final saved = await showDialog<bool>(context: context, builder: (_) => _SettingsDialog(settings: settings, service: service)); if (saved == true && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('在线咨询设置已保存。'))); }
  Future<void> _ask() async { if (scenario.text.trim().isEmpty) { setState(() => error = '请输入客户描述。'); return; } setState(() { busy = true; error = null; answer = null; }); try { final raw = await service.ask(scenario.text.trim(), widget.items); if (mounted) setState(() => answer = _guard(raw, scenario.text)); } catch (e) { if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', '')); } finally { if (mounted) setState(() => busy = false); } }
  @override Widget build(BuildContext context) { final grouped = <String, List<Map<String, dynamic>>>{'优先考虑': [], '可能涉及': [], '必须确认': []}; for (final item in answer?['applications'] as List? ?? []) { grouped[item['status'] as String]?.add(item.cast<String, dynamic>()); } return Scaffold(appBar: AppBar(title: const Text('在线场景咨询'), actions: [IconButton(tooltip: '设置 API', onPressed: _configure, icon: const Icon(Icons.settings_outlined))]), body: ListView(padding: const EdgeInsets.all(16), children: [const Text('输入客户的任何描述', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 7), Text('先列出可能需要涂装的所有部位，再给出候选体系。资料不覆盖的用途会明确提示技术确认。', style: TextStyle(color: Colors.grey.shade700, height: 1.5)), const SizedBox(height: 16), TextField(controller: scenario, minLines: 4, maxLines: 7, decoration: const InputDecoration(hintText: '例如：普通居民家厨房想翻新；海边酒店栏杆；炼金厂；食品加工车间地面', filled: true, fillColor: Colors.white, border: OutlineInputBorder())), const SizedBox(height: 12), FilledButton.icon(onPressed: busy ? null : _ask, icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.auto_awesome), label: Text(busy ? '正在理解场景...' : '开始咨询')), if (error != null) _notice(error!, true), if (answer != null) ...[const SizedBox(height: 16), Text(answer!['summary']?.toString() ?? '', style: const TextStyle(height: 1.6)), ...grouped.entries.where((entry) => entry.value.isNotEmpty).map((entry) => _resultGroup(entry.key, entry.value))]])); }
  Widget _notice(String value, bool warning) => Container(margin: const EdgeInsets.only(top: 14), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: warning ? const Color(0xfffff1d6) : const Color(0xffe5f3ef), borderRadius: BorderRadius.circular(8)), child: Text('$value\n\n未配置或网络不可用时，可使用主页右上角的离线场景库。', style: const TextStyle(height: 1.55)));
  Widget _resultGroup(String title, List<Map<String, dynamic>> data) {
    return Padding(
      padding: const EdgeInsets.only(top: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: title == '必须确认' ? const Color(0xff925b1c) : Theme.of(context).colorScheme.primary)),
          const SizedBox(height: 8),
          ...data.map((x) => Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(x['name'].toString(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 5),
                  Text(x['system'].toString(), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text((x['models'] as List).join('、')),
                  const SizedBox(height: 8),
                  Text('依据：${x['assumptions']}', style: TextStyle(color: Colors.grey.shade700)),
                  Text('仍需确认：${(x['missing'] as List).join('、')}', style: TextStyle(color: Colors.grey.shade700)),
                  const SizedBox(height: 6),
                  Text(x['notes'].toString(), style: const TextStyle(height: 1.45)),
                ],
              ),
            ),
          )),
        ],
      ),
    );
  }
}

class _SettingsDialog extends StatefulWidget { final Map<String, String> settings; final _ConsultationService service; const _SettingsDialog({required this.settings, required this.service}); @override State<_SettingsDialog> createState() => _SettingsDialogState(); }
class _SettingsDialogState extends State<_SettingsDialog> { late final TextEditingController url; late final TextEditingController model; late final TextEditingController key; bool saving = false; String? error;
  @override void initState() { super.initState(); url = TextEditingController(text: widget.settings['baseUrl']); model = TextEditingController(text: widget.settings['model']); key = TextEditingController(); }
  @override void dispose() { url.dispose(); model.dispose(); key.dispose(); super.dispose(); }
  Future<void> _save() async { setState(() { saving = true; error = null; }); try { await widget.service.saveSettings(baseUrl: url.text, model: model.text, apiKey: key.text); if (mounted) Navigator.pop(context, true); } catch (e) { if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', '')); } finally { if (mounted) setState(() => saving = false); } }
  @override Widget build(BuildContext context) => AlertDialog(title: const Text('在线咨询设置'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: url, decoration: const InputDecoration(labelText: 'API 地址', hintText: 'https://.../v1/chat/completions')), TextField(controller: model, decoration: const InputDecoration(labelText: '模型名', hintText: 'gpt-5.6-terra')), TextField(controller: key, obscureText: true, decoration: InputDecoration(labelText: 'API Key', hintText: widget.settings['configured'] == 'true' ? '已保存；留空则不修改' : '粘贴 API Key')), if (error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error!, style: const TextStyle(color: Colors.red)))])), actions: [TextButton(onPressed: saving ? null : () => Navigator.pop(context), child: const Text('取消')), FilledButton(onPressed: saving ? null : _save, child: Text(saving ? '保存中...' : '保存'))]);
}

class _ConsultationService {
  static const _storage = FlutterSecureStorage();
  Future<Map<String, String>> readSettings() async => {'baseUrl': await _storage.read(key: 'apiUrl') ?? 'https://rkapi.com/v1/chat/completions', 'model': await _storage.read(key: 'apiModel') ?? 'gpt-5.6-terra', 'configured': ((await _storage.read(key: 'apiKey'))?.isNotEmpty ?? false).toString()};
  Future<void> saveSettings({required String baseUrl, required String model, required String apiKey}) async { if (!baseUrl.trim().startsWith('https://')) throw Exception('API 地址必须以 https:// 开头。'); if (model.trim().isEmpty) throw Exception('请填写模型名。'); await _storage.write(key: 'apiUrl', value: baseUrl.trim()); await _storage.write(key: 'apiModel', value: model.trim()); if (apiKey.trim().isNotEmpty) await _storage.write(key: 'apiKey', value: apiKey.trim()); }
  Future<Map<String, dynamic>> ask(String scenario, List<Map<String, dynamic>> items) async { final settings = await readSettings(); final apiKey = await _storage.read(key: 'apiKey'); if (apiKey == null || apiKey.isEmpty) throw Exception('尚未配置 API Key。请点击右上角设置。'); final catalog = items.where((x) => x['type'] == 'product').map((x) => '${x['name']}: ${x['usage'] ?? x['summary'] ?? ''}').join('\n'); final prompt = '你是工业涂料选型助手。用户输入可能是任意行业、民用空间、构件或工况。不要要求用户先回答问题；先尽量完整列出可能涉及的涂装部位，再给出每个部位候选体系。只可使用给出的型号；民用家装、食品直接接触、饮用水、强酸碱或长期浸泡必须标记为“必须确认”，不得声称型号可直接适用。遵循够用就好。\n\n产品资料：$catalog\n\n用户描述：$scenario\n\n只返回 JSON：{"summary":"...","applications":[{"name":"部位","status":"优先考虑|可能涉及|必须确认","system":"体系","models":["YH-..."],"assumptions":"假设","missing":["需要确认的信息"],"notes":"说明"}]}'; final response = await http.post(Uri.parse(settings['baseUrl']!), headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $apiKey'}, body: jsonEncode({'model': settings['model'], 'temperature': .2, 'response_format': {'type': 'json_object'}, 'messages': [{'role': 'system', 'content': '你是严谨的工业涂料技术支持。'}, {'role': 'user', 'content': prompt}]})).timeout(const Duration(seconds: 45)); if (response.statusCode < 200 || response.statusCode >= 300) throw Exception('在线咨询服务返回 ${response.statusCode}，请检查 API 地址、模型名和 Key。'); final body = jsonDecode(response.body) as Map<String, dynamic>; final content = body['choices']?[0]?['message']?['content']; if (content is! String) throw Exception('在线咨询服务没有返回内容。'); try { return jsonDecode(content) as Map<String, dynamic>; } catch (_) { throw Exception('在线咨询服务返回的内容不是可识别的结构化结果。'); } }
}

Map<String, dynamic> _guard(Map<String, dynamic> raw, String scenario) { final source = raw['applications'] is List ? raw['applications'] as List : <dynamic>[]; return {'summary': raw['summary']?.toString() ?? '已按描述列出可能需要涂装的部位。', 'applications': source.take(12).map((entry) { final x = (entry as Map).cast<String, dynamic>(); final name = x['name']?.toString() ?? '候选涂装部位'; final context = '$scenario $name ${x['notes'] ?? ''} ${x['assumptions'] ?? ''}'; final restricted = _restrictedWords.any(context.contains); final models = ((x['models'] as List?) ?? <dynamic>[]).map((v) => v.toString()).where(_supportedModel).toList(); final status = restricted || models.isEmpty || x['status'] == '必须确认' ? '必须确认' : (x['status'] == '优先考虑' ? '优先考虑' : '可能涉及'); return {'name': name, 'status': status, 'system': x['system']?.toString() ?? '待技术确认的涂装体系', 'models': status == '必须确认' ? ['专项技术确认'] : models, 'assumptions': x['assumptions']?.toString() ?? '未取得完整基材、介质和施工条件。', 'missing': ((x['missing'] as List?) ?? ['基材与现有漆层']).take(5).map((v) => v.toString()).toList(), 'notes': restricted ? '现有资料未覆盖此类用途或其风险边界，不能将任何型号作为确定现货推荐。请由技术人员确认。' : x['notes']?.toString() ?? '最终施工前请确认表面处理和完整底中面配套。'}; }).toList()}; }
bool _supportedModel(String model) { final matches = RegExp(r'YH-\d+').allMatches(model.toUpperCase()).map((x) => x.group(0)).whereType<String>().toList(); return matches.isNotEmpty && matches.every(_documentedModels.contains); }

class SelectionPage extends StatefulWidget { const SelectionPage({super.key}); @override State<SelectionPage> createState() => _SelectionPageState(); }
class _SelectionPageState extends State<SelectionPage> { final scene = TextEditingController(); String? result;
  void run() { final text = scene.text; final options = text.contains('炼金') || text.contains('冶炼') ? '车间地坪、酸洗池/电镀槽、储罐/管道内壁、室外钢构、埋地管线、高温烟道。\n\n请使用“在线场景咨询”获得完整的自由描述分析。' : '离线场景库适用于已知部位和工况。请使用“在线场景咨询”输入任意行业或客户描述，先获得全部候选部位。'; setState(() => result = options); }
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('离线场景库')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('离线场景提示', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('网络不可用时仍可浏览资料与常见工业场景。任意描述的智能理解请使用主页右上角的在线咨询。'),
          const SizedBox(height: 16),
          TextField(controller: scene, decoration: const InputDecoration(labelText: '项目/场景描述', hintText: '例如：炼金厂、室外储罐、食品车间地面', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          FilledButton(onPressed: run, child: const Text('查看提示')),
          if (result != null)
            Card(
              margin: const EdgeInsets.only(top: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SelectableText(result!, style: const TextStyle(height: 1.6)),
              ),
            ),
        ],
      ),
    );
  }
}
