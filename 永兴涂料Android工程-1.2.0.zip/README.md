# 永兴涂料 Android 手机版 1.2.0

这是 Flutter 离线应用工程，资料已内置在 `assets/data-products.json`，无需服务器即可浏览。当前资料源为最新版中文版说明书的 31 类正式产品，并包含地坪施工/证书参考资料与工程案例图片。在线场景咨询使用用户在应用内配置的 OpenAI 兼容 API，密钥仅保存在该手机本机，不包含在工程或 APK 中。

## 在有 Flutter 环境的电脑生成 APK

```powershell
flutter create . --platforms=android
flutter pub get
flutter build apk --release
```

生成文件：`build\app\outputs\flutter-apk\app-release.apk`。

## 安装到手机

把 APK 发到 Android 手机，允许“安装未知来源应用”后点击安装即可。后续增加资料时，只需替换 `assets/data-products.json` 并重新构建。
