# Android 工程安全筛查

检查范围：`android-app` 当前 Flutter 源码、离线 JSON 资料、图片资源和 GitHub Actions 工作流。

## 已检查项目

- 产品目录、案例图片和施工资料均从应用内资源读取；不读取外部文件，也不执行动态代码。
- 未声明通讯录、定位、相机、存储等 Android 敏感权限；资料从应用内资源读取。
- JSON 只作为本地展示数据解析，不作为代码或路径执行。
- 搜索和详情页均只在内存中的内置资料上操作。
- 在线咨询仅在用户主动配置 OpenAI 兼容 API 后发起 HTTPS 请求；Key 使用系统安全存储保存在该手机本机，未写入源码、资料包或工作流。
- 工作流不读取 secrets，也不上传源码；只上传构建生成的 APK artifact。
- 依赖包括 Flutter SDK、`http`、`flutter_secure_storage`、`cupertino_icons` 和开发期 lint/test 工具。

## 低风险注意项

GitHub Actions 当前使用版本标签（如 `actions/checkout@v4`）。这属于供应链可追溯性改进项，不是当前应用漏洞；正式发布前可将 Actions 固定到具体 commit SHA。

## 结论

当前工程未发现可报告的高危或中危漏洞。由于本机没有 Android SDK，尚未生成最终 `AndroidManifest.xml` 和 APK；APK 构建后应再检查最终 Manifest 的权限列表，并运行 `flutter analyze`、`flutter test` 和发布包验证。
